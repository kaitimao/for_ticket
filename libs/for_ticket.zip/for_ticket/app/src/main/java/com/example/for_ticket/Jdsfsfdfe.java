package com.example.for_ticket;

import androidx.appcompat.app.AppCompatActivity;

public class Jdsfsfdfe extends AppCompatActivity {
}
